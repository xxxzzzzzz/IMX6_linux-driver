#ifndef __IIC_ANALOG_H
#define __IIC_ANALOG_H

unsigned long Read_HX711(void);
unsigned long get_weight(void);//get_pressure

#endif
