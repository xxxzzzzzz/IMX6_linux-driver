#ifndef __IIC_ANALOG3_H
#define __IIC_ANALOG3_H

unsigned long Read_HX711_3(void);
unsigned long get_weight_3(void);//get_pressure3

#endif
