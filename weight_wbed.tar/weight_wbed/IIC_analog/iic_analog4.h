#ifndef __IIC_ANALOG4_H
#define __IIC_ANALOG4_H

unsigned long Read_HX711_4(void);
unsigned long get_weight_4(void);//get_pressure2

#endif
