#ifndef __IIC_ANALOG2_H
#define __IIC_ANALOG2_H

unsigned long Read_HX711_2(void);
unsigned long get_weight_2(void);//get_pressure2

#endif
