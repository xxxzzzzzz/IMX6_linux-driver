#include <stdio.h>
#include <stdlib.h> 
#include <fcntl.h>
#include<sys/ioctl.h>
#include <unistd.h>

/*data[0] is temperature ,data[1] is humi*/


int main(){
int fd;
unsigned char data[2];
if((fd=open("/dev/threesboy_temphumi", O_RDWR | O_NDELAY))<0){ //open temphumi

printf("open temphumi failed!");	
}

while(1){
 read(fd, data, sizeof(data));//read temp humi value	
 printf("temperature = %d : humi = %d\n",data[0],data[1]);
 sleep(1);
}


return 0;
}
